function [ img_carved ] = main_v_h(img, max_iter)
tic
img = main_v(img, max_iter)

toc
end

